var level = 0;
toggle = false;
var coloursArray = ["green", "red", "yellow", "blue"];
var systemArray = [];
var userArray = [];

document.addEventListener("keydown", function () {
    if (!toggle) {

        sequence();
        toggle = true;

    }
});
var buttonLength = document.querySelectorAll(".btn").length;
for (var i = 0; i < buttonLength; i++) {
    document.querySelectorAll(".btn")[i].addEventListener("click", function (event) {
        userArray.push(event.target.id);
        console.log(userArray);
        soundBox(event.target.id);
        animateBox(event.target.id);
        checkAnswer(userArray.length-1);
        console.log(userArray.length);

    });
    
}


function checkAnswer(userArrayLength) {
    if(systemArray[userArrayLength]===userArray[userArrayLength])
    {
        if(systemArray.length===userArray.length)
        {
            setTimeout(function()
            {sequence();
            }
            ,1000);
           
        }
    }
    else
    {
        soundBox("wrong");
        document.querySelector("body").classList.add("game-over");
        document.querySelector("#level-title").innerHTML = ("Game Over, Press Any Key to Restart");
        setTimeout(function(){
            document.querySelector("body").classList.remove("game-over");
        },200);
        startAgain();
    }
}

function soundBox(sound) {
    var audio = new Audio("sounds/" + sound + ".mp3");
    audio.play();
}
function animateBox(currentColour) {
    document.querySelector("#" + currentColour).classList.add("pressed");
    setTimeout(function () {
        document.querySelector("#" + currentColour).classList.remove("pressed");
    }, 100);

}
function sequence() {
    userArray=[];
    level++;
    document.querySelector("#level-title").innerHTML = "Level " + level;
    var randomNumber = Math.floor(Math.random() * 4);
    var randomColour = coloursArray[randomNumber];
    systemArray.push(randomColour);
    console.log(systemArray);
    soundBox(randomColour);
    animateBox(randomColour);
    console.log(systemArray.length);
}
function startAgain()
{
    systemArray=[];
    level=0;
    toggle=false;
}